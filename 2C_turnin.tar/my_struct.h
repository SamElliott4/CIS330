/* This file should contain your struct definitions for Circle, Triangle, and 
   Rectangle */

typedef struct {
	double minX;
	double maxX;
	double minY;
	double maxY;
} Rectangle;

typedef struct {
	double radius;
	double originX;
	double originY;
} Circle;

typedef struct {
	double x1;
	double x2;
	double minY;
	double maxY;
} Triangle;
