/* This file should contain the 9 functions defined in prototypes.h */

#include <prototypes.h>

void InitializeRectangle(Rectangle * r, double minX, double maxX, double minY, double maxY){
	r->minX = minX;
	r->maxX = maxX;
	r->minY = minY;
	r->maxY = maxY;
}
void InitializeCircle(Circle * c, double rad, double oriX, double oriY){
	c->radius = rad;
	c->originX = oriX;
	c->originY = oriY;
}
void InitializeTriangle(Triangle * t, double pt1X, double pt2X, double minY, double maxY){
	t->x1 = pt1X;
	t->x2 = pt2X;
	t->minY = minY;
	t->maxY = maxY;
}

double GetRectangleArea(Rectangle * r){
	return (r->maxX - r->minX) * (r->maxY - r->minY);
}
double GetCircleArea(Circle * c){
	return c->radius*c->radius*3.14159;
}
double GetTriangleArea(Triangle * t){
	return (t->x2 - t->x1) * (t->maxY - t->minY) / 2;
}

void GetRectangleBoundingBox(Rectangle * r, double * b){
	b[0] = r->minX;
	b[1] = r->maxX;
	b[2] = r->minY;
	b[3] = r->maxY;
}
void GetCircleBoundingBox(Circle * c, double * b){
	b[0] = c->originX - c->radius;	
	b[1] = c->originX + c->radius;
	b[2] = c->originY - c->radius;
	b[3] = c->originY + c->radius;
}
void GetTriangleBoundingBox(Triangle * t, double * b){	
	b[0] = t->x1;	
	b[1] = t->x2;
	b[2] = t->minY;
	b[3] = t->maxY;
}
