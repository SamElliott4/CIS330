/* This file should contain the 9 functions defined in prototypes.h */

#include <prototypes.h>

void InitializeRectangle(struct Shape * s, double minX, double maxX, double minY, double maxY){
	s->st = rect; 
	s->sh.r.minX = minX;
	s->sh.r.maxX = maxX;
	s->sh.r.minY = minY;
	s->sh.r.maxY = maxY;
	s->ft.GetArea = GetRectangleArea;
	s->ft.GetBoundingBox = GetRectangleBoundingBox;
}
void InitializeCircle(struct Shape * s, double rad, double oriX, double oriY){
	s->st = cir;
	s->sh.c.radius = rad;
	s->sh.c.originX = oriX;
	s->sh.c.originY = oriY;
	s->ft.GetArea = GetCircleArea;
	s->ft.GetBoundingBox = GetCircleBoundingBox;
}
void InitializeTriangle(struct Shape * s, double pt1X, double pt2X, double minY, double maxY){
	s->st = tri;
	s->sh.t.x1 = pt1X;
	s->sh.t.x2 = pt2X;
	s->sh.t.minY = minY;
	s->sh.t.maxY = maxY;
	s->ft.GetArea = GetTriangleArea;
	s->ft.GetBoundingBox = GetTriangleBoundingBox;
}

double GetRectangleArea(struct Shape * s){
	return (s->sh.r.maxX - s->sh.r.minX) * (s->sh.r.maxY - s->sh.r.minY);
}
double GetCircleArea(struct Shape * s){
	return s->sh.c.radius*s->sh.c.radius*3.14159;
}
double GetTriangleArea(struct Shape * s){
	return (s->sh.t.x2 - s->sh.t.x1) * (s->sh.t.maxY - s->sh.t.minY) / 2;
}

void GetRectangleBoundingBox(struct Shape * s, double * b){
	b[0] = s->sh.r.minX;
	b[1] = s->sh.r.maxX;
	b[2] = s->sh.r.minY;
	b[3] = s->sh.r.maxY;
}
void GetCircleBoundingBox(struct Shape * s, double * b){
	b[0] = s->sh.c.originX - s->sh.c.radius;	
	b[1] = s->sh.c.originX + s->sh.c.radius;
	b[2] = s->sh.c.originY - s->sh.c.radius;
	b[3] = s->sh.c.originY + s->sh.c.radius;
}
void GetTriangleBoundingBox(struct Shape * s, double * b){	
	b[0] = s->sh.t.x1;	
	b[1] = s->sh.t.x2;
	b[2] = s->sh.t.minY;
	b[3] = s->sh.t.maxY;
}
