#ifndef FILTERS_H
#define FILTERS_H

#include "source.h"
#include "sink.h"
#include "image.h"

class Filter : public Source, public Sink{
	public:
	Filter(void);
	virtual ~Filter(void);
	virtual void Execute() = 0;
	
};

class Shrinker : public Filter{
	public:
	Shrinker(void);
	virtual ~Shrinker(void);

	virtual void Execute();
};

class LRConcat : public Filter{
	public:
	LRConcat(void);
	virtual ~LRConcat(void);

	virtual void Execute();
};

class TBConcat : public Filter{
	public:
	TBConcat(void);
	virtual ~TBConcat(void);

	virtual void Execute();
};

class Blender : public Filter{
	private:
	float factor;

	public:
	Blender(void);
	virtual ~Blender(void);

	virtual void Execute();
	void SetFactor(float f);
};

#endif
