#include "PNMreader.h"
#include "image.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// PNMreader
PNMreader::PNMreader(char * infile){
	filename = strdup(infile);
}
PNMreader::~PNMreader(void){
	free(filename);
}

void PNMreader::Execute(){
	FILE * f = fopen(filename, "rb");
	char magicNum[128];
	int width, height, maxval;

	fscanf(f, "%s\n%d %d\n%d\n", magicNum, &width, &height, &maxval);

	output.ResetSize(height, width);
	output.SetMaxval(maxval);
	output.InitData();

	Pixel *data = output.GetData();
	fread(data, 3, height*width, f);

	fclose(f);
}

