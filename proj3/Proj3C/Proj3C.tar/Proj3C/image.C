#include <stdlib.h>
#include <image.h>
#include <string.h>


Image::Image(void){
	ResetSize(0, 0);
	maxval = 255;
	InitData();
}
Image::Image(Image &im){
	ResetSize(im.GetHeight(), im.GetWidth());
	maxval = im.maxval;
	InitData();
	memcpy(data, im.GetData(), im.GetHeight()*im.GetWidth()*sizeof(Pixel));
}
Image::Image(Pixel * p, int h, int w, int mv){
	ResetSize(h, w);
	maxval = mv;
	data = p;
}

Image::~Image(void){
	if(data != NULL){free(data);}
	data = NULL;
}

void Image::ResetSize(int h, int w){
	height = h; width = w;
}
void Image::SetMaxval(int mv){
	maxval = mv;
}
void Image::InitData(){
	//if(data != NULL){free(data);}
	data = (Pixel *) malloc(width*height*sizeof(Pixel));
}

int Image::GetHeight(){
	return height;
}
int Image::GetWidth(){
	return width;
}
int Image::GetMaxval(){
	return maxval;
}
Pixel * Image::GetData(){
	return data;
}
