#ifndef PNMREADER_H
#define PNMREADER_H

#include "image.h"
#include "source.h"

class PNMreader : public Source{
	
	char * filename;	

	public:
	PNMreader(char * str);
	virtual ~PNMreader(void);	

	virtual void Execute();
};

#endif
