#include "PNMwriter.h"
#include "image.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

PNMwriter::PNMwriter(void){
	;
}
PNMwriter::~PNMwriter(void){
	;
}	

void PNMwriter::Write(char *outfile){
	FILE * f_out = fopen(outfile, "wb");

	fprintf(f_out, "P6\n%d %d\n%d\n", input1->GetWidth(), input1->GetHeight(), input1->GetMaxval());
	Pixel *data = input1->GetData();
	fwrite(data, 3, input1->GetWidth()*input1->GetHeight(), f_out);
	fclose(f_out);
}
