#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
	unsigned char r;
	unsigned char g;
	unsigned char b;
} Pixel;

typedef struct
{
	Pixel *data;
	int height;
	int width;
	int maxval;
} Image;

Image *
ReadImage(char *filename)
{
FILE *f_in;
char magicNum[128];
int width, height, maxval;

f_in = fopen(filename, "rb");
fscanf(f_in, "%s\n%d %d\n%d\n", magicNum, &width, &height, &maxval);

Image *img = malloc(sizeof(Image *));
img->data = malloc(height*width*sizeof(Pixel));
img->width = width;
img->height = height;
img->maxval = maxval;

fread(img->data, 3, height*width, f_in);

fclose(f_in);

return img;
}


void WriteImage(Image *img, char *filename)
{
	FILE *f_out;
	f_out = fopen(filename, "wb");

	fprintf(f_out, "P6\n%d %d\n%d\n", img->width, img->height, img->maxval);
	fwrite(img->data, 3, img->width*img->height, f_out);
	fclose(f_out);	
}

Image *
YellowDiagonal(Image *input)
{

	Image *mod_img = malloc(sizeof(Image));
	mod_img->data = malloc(sizeof(Pixel)*input->height*input->width);
	memcpy(mod_img->data, input->data, sizeof(Pixel)*input->width*input->height);
	mod_img->height = input->height;
	mod_img->width = input->width;
	mod_img->maxval = input->maxval;

	int i = 0;
	while(i<mod_img->height*mod_img->width){
		mod_img->data[i].r=mod_img->maxval;
		mod_img->data[i].g=mod_img->maxval;
		mod_img->data[i].b=0;
		i += mod_img->width+1;
	}
	return mod_img;
}

int main(int argc, char *argv[])
{
	Image *img;
	img = ReadImage(argv[1]);
	Image *mod_img;
	mod_img = YellowDiagonal(img);

	WriteImage(mod_img, argv[2]);
	
	free(img->data);
	free(img);
	free(mod_img->data);
	free(mod_img);
}
