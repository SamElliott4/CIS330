#include <source.h>
#include <image.h>
#include <iostream>

using std::cout;
using std::endl;

// Source
Source::Source(void){
	;
}
Source::~Source(void){
	;
}

Image * Source::GetOutput(){
	return &output;
}

