#include "filters.h"
#include <string.h>
#include <iostream>
#include <stdio.h>
#include <logging.h>

using std::cout;
using std::endl;

// Filter
Filter::Filter(void){
	input1 = NULL;
	input2 = NULL;
}
Filter::~Filter(void){;}
const char * Filter::SourceName(){
	return FilterName();
}
const char * Filter::SinkName(){
	return FilterName();
}
void Filter::Update(){	
	char msg[128];
	if(!(input1==NULL)){
		sprintf(msg, "%s: about to update input1", SourceName());
		Logger::LogEvent(msg);
		input1->Update();
		sprintf(msg, "%s: done updating input1", SourceName());
		Logger::LogEvent(msg);
	}
	if(!(input2==NULL)){
		sprintf(msg, "%s: about to update input2", SourceName());
		Logger::LogEvent(msg);
		input2->Update();
		sprintf(msg, "%s: done updating input2", SourceName());
		Logger::LogEvent(msg);
	}
	sprintf(msg, "%s: about to execute", SourceName());
	Logger::LogEvent(msg);
	this->Execute();
	sprintf(msg, "%s: done executing", SourceName());
	Logger::LogEvent(msg);
}


// Shrinker
Shrinker::Shrinker(void){
	output.SetSource(this);
}
Shrinker::~Shrinker(void){;}

void Shrinker::Execute(){
	char msg[128];

	// Error checks
	if(input1 == NULL){
		sprintf(msg, "%s: no input1!", SinkName());
		DataFlowException e(SinkName(), msg);
		throw e;
	}

	//Begin execution
	if(!(output.IsCurrent())){
		output.ResetSize((this->input1->GetHeight()+1)/2, (this->input1->GetWidth()+1)/2);
		output.InitData();
		Pixel * outData = output.GetData();
		Pixel * inData = this->input1->GetData();
		int outHeight = output.GetHeight();
		int outWidth = output.GetWidth();
		int inWidth = this->input1->GetWidth();
		for(int i = 0; i < outHeight; i++){
			for(int j = 0; j<outWidth; j++){
				outData[i*outWidth+j] = inData[i*2*inWidth+j*2];
			}
		}
	output.SetCurrent(true); 
	}
}
void Shrinker::Update(){
	Filter::Update();
}
const char *Shrinker::FilterName(){
	return "Shrinker";
}


// LRConcat
LRConcat::LRConcat(void){
	output.SetSource(this);
}
LRConcat::~LRConcat(void){;}

void LRConcat::Execute(){
	char msg[128];

	// Error checks
	if(input1 == NULL){
		sprintf(msg, "%s: no input1!", SinkName());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	if(input2 == NULL){
		sprintf(msg, "%s: no input2!", SinkName());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	if(!(input1->GetHeight() == input2->GetHeight())){
		sprintf(msg, "%s: heights must match: %d, %d", SinkName(), input1->GetHeight(), input2->GetHeight());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	
	// Begin execution
	if(!output.IsCurrent()){
	
		output.ResetSize(input1->GetHeight(), input1->GetWidth() + input2->GetWidth());
		output.InitData();
		int outHeight = output.GetHeight();
		int outWidth = output.GetWidth();
		int leftWidth = input1->GetWidth();
		int rightWidth = input2->GetWidth();
		Pixel *outData = output.GetData();
		Pixel *leftData = input1->GetData();
		Pixel *rightData = input2->GetData();

		for(int i = 0; i < outHeight; i++){
			memcpy(outData + i*outWidth, leftData + i*leftWidth, leftWidth*sizeof(Pixel));
			memcpy(outData + i*outWidth + leftWidth, rightData + i*rightWidth, rightWidth*sizeof(Pixel));
		}
		output.SetCurrent(true); 
	}
}
void LRConcat::Update(){
	Filter::Update();
}

const char *LRConcat::FilterName(){
	return "LRConcat";
}

// TBConcat
TBConcat::TBConcat(void){
	output.SetSource(this);
}
TBConcat::~TBConcat(void){;}

void TBConcat::Execute(){
	char msg[128];

	// Error checks
	if(input1 == NULL){
		sprintf(msg, "%s: no input1!", SinkName());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	if(input2 == NULL){
		sprintf(msg, "%s: no input2!", SinkName());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	if(!(input1->GetWidth() == input2->GetWidth())){
		sprintf(msg, "%s: widths must match: %d, %d", SinkName(), input1->GetWidth(), input2->GetWidth());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	
	// Begin execution
	if(!output.IsCurrent()){

		output.ResetSize(input1->GetHeight() + input2->GetHeight(), input1->GetWidth());
		output.InitData();
		Pixel * outData = output.GetData();
		memcpy(outData, input1->GetData(), input1->GetHeight()*input1->GetWidth()*sizeof(Pixel));
		memcpy(outData + input1->GetHeight()*input1->GetWidth(), input2->GetData(), input2->GetHeight()*input2->GetWidth()*sizeof(Pixel));
		output.SetCurrent(true); 
	}
}
void TBConcat::Update(){
	Filter::Update();
}

const char *TBConcat::FilterName(){
	return "TBConcat";
}


// Blender
Blender::Blender(void){
	output.SetSource(this);
}
Blender::~Blender(void){;}

void Blender::Execute(){
	char msg[128];

	// Error checks
	if(input1 == NULL){
		sprintf(msg, "%s: no input1!", SinkName());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	if(input2 == NULL){
		sprintf(msg, "%s: no input2!", SinkName());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	if(!(input1->GetHeight() == input2->GetHeight())){
		sprintf(msg, "%s: heights must match: %d, %d", SinkName(), input1->GetHeight(), input2->GetHeight());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	if(!(input1->GetWidth() == input2->GetWidth())){
		sprintf(msg, "%s: widths must match: %d, %d", SinkName(), input1->GetWidth(), input2->GetWidth());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	if(factor < 0.0 or factor>1.0){
		sprintf(msg, "Invalid factor for Blender: %f", factor);
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	
	// Begin execution
	if(!output.IsCurrent()){

		output.ResetSize(input1->GetHeight(), input2->GetWidth());
		output.InitData();
		Pixel *outData = output.GetData();
		Pixel *input1Data = input1->GetData();
		Pixel *input2Data = input2->GetData();
		int outHeight = output.GetHeight();
		int outWidth = output.GetWidth();
		for(int i = 0; i < outHeight*outWidth; i++){
			outData[i].r = input1Data[i].r * factor + input2Data[i].r * (1-factor);
			outData[i].g = input1Data[i].g * factor + input2Data[i].g * (1-factor);
			outData[i].b = input1Data[i].b * factor + input2Data[i].b * (1-factor);
		}
		output.SetCurrent(true); 
	}
}
void Blender::Update(){
	Filter::Update();
}
void Blender::SetFactor(float f){
	factor = f;
}
const char *Blender::FilterName(){
	return "Blender";
}
