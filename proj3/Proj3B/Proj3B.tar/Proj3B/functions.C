#include <functions.h>
#include <stdio.h>
#include <string.h>

void ReadImage(char *filename, Image &output){
	FILE * f;
	char magicNum[128];
	int width, height, maxval;

	f = fopen(filename, "rb");
	fscanf(f, "%s\n%d %d\n%d\n", magicNum, &width, &height, &maxval);

	output.ResetSize(height, width);
	output.data = (Pixel *) malloc(height*width*sizeof(Pixel));
	output.maxval = maxval;
	
	fread(output.data, 3, height*width, f);

	fclose(f);
}

void WriteImage(char *filename, Image &img){
	FILE * f_out = fopen(filename, "wb");

	fprintf(f_out, "P6\n%d %d\n%d\n", img.width, img.height, img.maxval);
	fwrite(img.data, 3, img.width*img.height, f_out);
	fclose(f_out);
}



void HalveInSize(Image &input, Image &output){
	output.ResetSize((input.height+1)/2, (input.width+1)/2);
		// +1 is in case there are an odd number of pixels in a dimension
		// proceduce for halving the size would result in rounding up.
		// e.g. if input.width = 11, there are 6 pixels that would be preserved,
		// data[0] [2] [4] [6] [8] [10] from the first row
		// If dimensions are even to begin with, integer division will round back down
	output.InitData();
	for(int i = 0; i<output.height; i++){
		for(int j = 0; j<output.width; j++){
			(output.data)[i*output.width+j] = (input.data)[i*2*input.width+j*2];
		}
	}
	output.maxval = input.maxval;
}

void LeftRightConcatenate(Image &leftInput, Image &rightInput, Image &output){
	output.ResetSize(leftInput.height, leftInput.width+rightInput.width);
	output.InitData();
	for(int i = 0; i < output.height; i++){
		memcpy(output.data + i*output.width, leftInput.data + i*leftInput.width, leftInput.width*sizeof(Pixel));
		memcpy(output.data + i*output.width + leftInput.width, rightInput.data + i*rightInput.width, rightInput.width*sizeof(Pixel));
	}
}

void TopBottomConcatenate(Image &topInput, Image &bottomInput, Image &output){
	output.ResetSize(topInput.height + bottomInput.height, topInput.width);
	output.InitData();
	memcpy(output.data, topInput.data, topInput.height*topInput.width*sizeof(Pixel));
	memcpy(output.data + topInput.height*topInput.width, bottomInput.data, bottomInput.height*bottomInput.width*sizeof(Pixel));
}

void Blend(Image &input1, Image &input2, float factor, Image &output){
	output.ResetSize(input1.height, input1.width);
	output.InitData();
	for(int i = 0; i < output.width*output.height; i++){
		(output.data)[i].r = (input1.data)[i].r * factor + (input2.data)[i].r * (1-factor); 
		(output.data)[i].g = (input1.data)[i].g * factor + (input2.data)[i].g * (1-factor); 
		(output.data)[i].b = (input1.data)[i].b * factor + (input2.data)[i].b * (1-factor); 
	}
}
