#include <stdlib.h>
#include <image.h>
#include <string.h>

Pixel::Pixel(void){r=0;g=0;b=0;}
Pixel::Pixel(unsigned char red, unsigned char green, unsigned char blue){
	r=red; g=green; b=blue;
}



Image::Image(void){
	ResetSize(0, 0);
	maxval = 255;
	InitData();
}
Image::Image(const Image &im){
	ResetSize(im.height, im.width);
	maxval = im.maxval;
	InitData();
	memcpy(data, im.data, im.height*im.width*sizeof(Pixel));
}
Image::Image(Pixel * p, int h, int w, int mv){
	ResetSize(h, w);
	maxval = mv;
	data = p;
}

Image::~Image(void){
	if(data != 0){free(data);}
}

void Image::ResetSize(int h, int w){
	height = h; width = w;
}
void Image::InitData(){
	data = (Pixel *) malloc(width*height*sizeof(Pixel));
}

