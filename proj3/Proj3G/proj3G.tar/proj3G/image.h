#ifndef IMAGE_H
#define IMAGE_H

// Forward declaration for source data memeber of Image
class Source;

struct Pixel{
	unsigned char r, g, b;
};

class Image{
	Pixel * data;
	int height;
	int width;
	int maxval;
	bool current;
	Source * source;

	public:
	// Constructors
	Image(void);
	Image(Image &);
	Image(Pixel * p, int h, int w, int mv);

	// Desctructor
	virtual ~Image(void);

	// Methods
	void ResetSize(int h, int w);
	void SetMaxval(int mv);
	void InitData();
	int GetHeight();
	int GetWidth();
	int GetMaxval();
	Pixel * GetData();
	Pixel * GetPixelAt(int i, int j); // pointer to pixel at row i column j
	void Update();
	bool IsCurrent();
	void SetCurrent(bool);
	void SetSource(Source *);
};

#endif
