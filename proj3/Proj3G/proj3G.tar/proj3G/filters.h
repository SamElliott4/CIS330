#ifndef FILTERS_H
#define FILTERS_H

#include "source.h"
#include "sink.h"
#include "image.h"

class Filter : public Source, public Sink{
	protected:
	virtual void Execute() = 0;

	public:
	Filter(void);
	virtual ~Filter(void);
	virtual void Update();
	virtual const char *FilterName() = 0;
	virtual const char *SourceName();
	virtual const char *SinkName();
};

class Shrinker : public Filter{
	protected:
	virtual void Execute();

	public:
	Shrinker(void);
	virtual ~Shrinker(void);
	virtual void Update();
	virtual const char *FilterName();
};

class LRConcat : public Filter{
	protected:
	virtual void Execute();

	public:
	LRConcat(void);
	virtual ~LRConcat(void);
	virtual void Update();
	virtual const char *FilterName();
};

class TBConcat : public Filter{
	protected:
	virtual void Execute();

	public:
	TBConcat(void);
	virtual ~TBConcat(void);
	virtual void Update();
	virtual const char *FilterName();
};

class Blender : public Filter{
	protected:
	virtual void Execute();

	private:
	float factor;

	public:
	Blender(void);
	virtual ~Blender(void);
	virtual void Update();
	virtual const char *FilterName();

	void SetFactor(float f);
};

class Mirror : public Filter{
	protected:
	virtual void Execute();

	public:
	Mirror(void);
	virtual ~Mirror(void);
	virtual void Update();
	virtual const char *FilterName();
};

class Rotate : public Filter{
	protected:
	virtual void Execute();

	public:
	Rotate(void);
	virtual ~Rotate(void);
	virtual void Update();
	virtual const char *FilterName();
};

class Subtract : public Filter{
	protected:
	virtual void Execute();

	public:
	Subtract(void);
	virtual ~Subtract(void);
	virtual void Update();
	virtual const char *FilterName();
};

class Grayscale : public Filter{
	protected:
	virtual void Execute();

	public:
	Grayscale(void);
	virtual ~Grayscale(void);
	virtual void Update();
	virtual const char *FilterName();
};

class Blur : public Filter{
	protected:
	virtual void Execute();
	
	public:
	Blur(void);
	virtual ~Blur(void);
	virtual void Update();
	virtual const char *FilterName();
};

class Color : public Source{
	private:
	int height, width;
	unsigned char red, green, blue;

	protected:
	virtual void Execute();

	public:
	Color(void);
	Color(int width, int height, unsigned char r, unsigned char g, unsigned char b);
	virtual ~Color(void);
	virtual void Update();
	virtual const char *SourceName();
};

class CheckSum : public Sink{
	protected:

	public:
	CheckSum(void);
	virtual ~CheckSum(void);
	virtual void OutputCheckSum(const char *filename);
	virtual const char *SinkName();
};
#endif
