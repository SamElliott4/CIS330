#ifndef IMAGE_H
#define IMAGE_H

// Forward declaration for source data memeber of Image
class Source;

struct Pixel{
	unsigned char r, g, b;
};

class Image{
	Pixel * data;
	int height;
	int width;
	int maxval;
	bool current;
	Source * source;

	public:
	// Constructors
	Image(void);
	Image(Image &);
	Image(Pixel * p, int h, int w, int mv);

	// Desctructor
	virtual ~Image(void);

	// Methods
	void ResetSize(int h, int w);
	void SetMaxval(int mv);
	void InitData();
	int GetHeight() const;
	int GetWidth() const;
	int GetMaxval() const;
	Pixel * GetData() const;
	void Update() const;
	bool IsCurrent();
	void SetCurrent(bool);
	void SetSource(Source *);
};

#endif
