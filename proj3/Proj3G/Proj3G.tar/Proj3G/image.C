#include <stdlib.h>
#include <image.h>
#include <string.h>
#include <source.h>
#include <iostream>
using namespace std;


Image::Image(void){
	ResetSize(0, 0);
	maxval = 255;
	current = false;
	InitData();
}
Image::Image(Image &im){
	ResetSize(im.GetHeight(), im.GetWidth());
	maxval = im.maxval;
	InitData();
	memcpy(data, im.GetData(), im.GetHeight()*im.GetWidth()*sizeof(Pixel));
}
Image::Image(Pixel * p, int h, int w, int mv){
	ResetSize(h, w);
	maxval = mv;
	data = p;
	current = false;
}

Image::~Image(void){
	if(data != NULL){free(data);}
	data = NULL;
}

void Image::ResetSize(int h, int w){
	height = h; width = w;
}
void Image::SetMaxval(int mv){
	maxval = mv;
}
void Image::InitData(){
	//if(data != NULL){free(data);}
	data = (Pixel *) malloc(width*height*sizeof(Pixel));
}

int Image::GetHeight() const{
	return height;
}
int Image::GetWidth() const{
	return width;
}
int Image::GetMaxval() const{
	return maxval;
}
Pixel * Image::GetData() const{
	return data;
}
bool Image::IsCurrent(){
	return current;
}
void Image::SetCurrent(bool b){
	current = b;
}
void Image::SetSource(Source *s){
	source = s;
}
void Image::Update() const{
	source->Update();
}
