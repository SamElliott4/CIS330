#include "filters.h"
#include <string.h>
#include <iostream>
#include <stdio.h>
#include <logging.h>
#include <fstream>

using std::cout;
using std::endl;
using std::ofstream;

// Filter
Filter::Filter(void){
	input1 = NULL;
	input2 = NULL;
}
Filter::~Filter(void){;}
const char * Filter::SourceName(){
	return FilterName();
}
const char * Filter::SinkName(){
	return FilterName();
}
void Filter::Update(){	
	char msg[128];
	if(!(input1==NULL)){
		sprintf(msg, "%s: about to update input1", SourceName());
		Logger::LogEvent(msg);
		input1->Update();
		sprintf(msg, "%s: done updating input1", SourceName());
		Logger::LogEvent(msg);
	}
	if(!(input2==NULL)){
		sprintf(msg, "%s: about to update input2", SourceName());
		Logger::LogEvent(msg);
		input2->Update();
		sprintf(msg, "%s: done updating input2", SourceName());
		Logger::LogEvent(msg);
	}
	sprintf(msg, "%s: about to execute", SourceName());
	Logger::LogEvent(msg);
	this->Execute();
	sprintf(msg, "%s: done executing", SourceName());
	Logger::LogEvent(msg);
}


// Shrinker
Shrinker::Shrinker(void){
	output.SetSource(this);
}
Shrinker::~Shrinker(void){;}

void Shrinker::Execute(){
	char msg[128];

	// Error checks
	if(input1 == NULL){
		sprintf(msg, "%s: no input1!", SinkName());
		DataFlowException e(SinkName(), msg);
		throw e;
	}

	//Begin execution
	if(!(output.IsCurrent())){
		output.ResetSize((this->input1->GetHeight()+1)/2, (this->input1->GetWidth()+1)/2);
		output.InitData();
		Pixel * outData = output.GetData();
		Pixel * inData = this->input1->GetData();
		int outHeight = output.GetHeight();
		int outWidth = output.GetWidth();
		int inWidth = this->input1->GetWidth();
		for(int i = 0; i < outHeight; i++){
			for(int j = 0; j<outWidth; j++){
				outData[i*outWidth+j] = inData[i*2*inWidth+j*2];
			}
		}
	output.SetCurrent(true); 
	}
}
void Shrinker::Update(){
	Filter::Update();
}
const char *Shrinker::FilterName(){
	return "Shrinker";
}


// LRConcat
LRConcat::LRConcat(void){
	output.SetSource(this);
}
LRConcat::~LRConcat(void){;}

void LRConcat::Execute(){
	char msg[128];

	// Error checks
	if(input1 == NULL){
		sprintf(msg, "%s: no input1!", SinkName());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	if(input2 == NULL){
		sprintf(msg, "%s: no input2!", SinkName());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	if(!(input1->GetHeight() == input2->GetHeight())){
		sprintf(msg, "%s: heights must match: %d, %d", SinkName(), input1->GetHeight(), input2->GetHeight());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	
	// Begin execution
	if(!output.IsCurrent()){
	
		output.ResetSize(input1->GetHeight(), input1->GetWidth() + input2->GetWidth());
		output.InitData();
		int outHeight = output.GetHeight();
		int outWidth = output.GetWidth();
		int leftWidth = input1->GetWidth();
		int rightWidth = input2->GetWidth();
		Pixel *outData = output.GetData();
		Pixel *leftData = input1->GetData();
		Pixel *rightData = input2->GetData();

		for(int i = 0; i < outHeight; i++){
			memcpy(outData + i*outWidth, leftData + i*leftWidth, leftWidth*sizeof(Pixel));
			memcpy(outData + i*outWidth + leftWidth, rightData + i*rightWidth, rightWidth*sizeof(Pixel));
		}
		output.SetCurrent(true); 
	}
}
void LRConcat::Update(){
	Filter::Update();
}

const char *LRConcat::FilterName(){
	return "LRConcat";
}

// TBConcat
TBConcat::TBConcat(void){
	output.SetSource(this);
}
TBConcat::~TBConcat(void){;}

void TBConcat::Execute(){
	char msg[128];

	// Error checks
	if(input1 == NULL){
		sprintf(msg, "%s: no input1!", SinkName());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	if(input2 == NULL){
		sprintf(msg, "%s: no input2!", SinkName());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	if(!(input1->GetWidth() == input2->GetWidth())){
		sprintf(msg, "%s: widths must match: %d, %d", SinkName(), input1->GetWidth(), input2->GetWidth());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	
	// Begin execution
	if(!output.IsCurrent()){

		output.ResetSize(input1->GetHeight() + input2->GetHeight(), input1->GetWidth());
		output.InitData();
		Pixel * outData = output.GetData();
		memcpy(outData, input1->GetData(), input1->GetHeight()*input1->GetWidth()*sizeof(Pixel));
		memcpy(outData + input1->GetHeight()*input1->GetWidth(), input2->GetData(), input2->GetHeight()*input2->GetWidth()*sizeof(Pixel));
		output.SetCurrent(true); 
	}
}
void TBConcat::Update(){
	Filter::Update();
}

const char *TBConcat::FilterName(){
	return "TBConcat";
}


// Blender
Blender::Blender(void){
	output.SetSource(this);
}
Blender::~Blender(void){;}

void Blender::Execute(){
	char msg[128];

	// Error checks
	if(input1 == NULL){
		sprintf(msg, "%s: no input1!", SinkName());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	if(input2 == NULL){
		sprintf(msg, "%s: no input2!", SinkName());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	if(!(input1->GetHeight() == input2->GetHeight())){
		sprintf(msg, "%s: heights must match: %d, %d", SinkName(), input1->GetHeight(), input2->GetHeight());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	if(!(input1->GetWidth() == input2->GetWidth())){
		sprintf(msg, "%s: widths must match: %d, %d", SinkName(), input1->GetWidth(), input2->GetWidth());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	if(factor < 0.0 or factor>1.0){
		sprintf(msg, "Invalid factor for Blender: %f", factor);
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	
	// Begin execution
	if(!output.IsCurrent()){

		output.ResetSize(input1->GetHeight(), input2->GetWidth());
		output.InitData();
		Pixel *outData = output.GetData();
		Pixel *input1Data = input1->GetData();
		Pixel *input2Data = input2->GetData();
		int outHeight = output.GetHeight();
		int outWidth = output.GetWidth();
		for(int i = 0; i < outHeight*outWidth; i++){
			outData[i].r = input1Data[i].r * factor + input2Data[i].r * (1-factor);
			outData[i].g = input1Data[i].g * factor + input2Data[i].g * (1-factor);
			outData[i].b = input1Data[i].b * factor + input2Data[i].b * (1-factor);
		}
		output.SetCurrent(true); 
	}
}
void Blender::Update(){
	Filter::Update();
}
void Blender::SetFactor(float f){
	factor = f;
}
const char *Blender::FilterName(){
	return "Blender";
}


// Mirror
Mirror::Mirror(void){
	output.SetSource(this);
}
Mirror::~Mirror(void){;}
void Mirror::Execute(){
	char msg[128];

	// Error checks
	if(input1 == NULL){
		sprintf(msg, "%s: no input1!", SinkName());
		DataFlowException e(SinkName(), msg);
		throw e;
	}

	// Begin execution
	if(!(output.IsCurrent())){
		output.ResetSize(input1->GetHeight(), input1->GetWidth());
		output.InitData();
		int height = output.GetHeight();
		int width = output.GetWidth();
		Pixel *outData = output.GetData();
		Pixel *inData = input1->GetData();

		for(int i = 0; i < height; i++){
			for(int j = 0; j < width; j++){
				outData[i * width + j] = inData[i*width + (width-1-j)];
			}
		}
		output.SetCurrent(true);
	}
}
void Mirror::Update(){
	Filter::Update();
}
const char *Mirror::FilterName(){
	return "Mirror";
}


// Rotate
Rotate::Rotate(void){
	output.SetSource(this);
}
Rotate::~Rotate(void){;}
void Rotate::Execute(){
	char msg[128];

	// Error checks
	if(input1 == NULL){
		sprintf(msg, "%s: no input1!", SinkName());
		DataFlowException e(SinkName(), msg);
		throw e;
	}

	// Begin Execution
	if(!(output.IsCurrent())){
		output.ResetSize(input1->GetWidth(), input1->GetHeight());
		output.InitData();
		int outWidth = output.GetWidth();
		int outHeight = output.GetHeight();
		int inWidth = outHeight;
		int inHeight = outWidth;
		Pixel *outData = output.GetData();
		Pixel *inData = input1->GetData();

		for(int i = 0; i < outHeight; i++){
			for(int j = 0; j < outWidth; j++){
				outData[i * outWidth + j] = inData[(inHeight-1-j) * inWidth + i];
			}
		}
		output.SetCurrent(true);
	}
}
void Rotate::Update(){
	Filter::Update();
}
const char *Rotate::FilterName(){
	return "Rotate";
}


// Subtract
Subtract::Subtract(void){
	output.SetSource(this);
}
Subtract::~Subtract(void){;}
void Subtract::Execute(){
	char msg[128];

	// Error Checks
	if(input1 == NULL){
		sprintf(msg, "%s: no input1!", SinkName());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	if(input2 == NULL){
		sprintf(msg, "%s: no input2!", SinkName());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	if(!(input1->GetHeight() == input2->GetHeight())){
		sprintf(msg, "%s: heights must match: %d, %d", SinkName(), input1->GetHeight(), input2->GetHeight());
		DataFlowException e(SinkName(), msg);
		throw e;
	}
	if(!(input1->GetWidth() == input2->GetWidth())){
		sprintf(msg, "%s: widths must match: %d, %d", SinkName(), input1->GetWidth(), input2->GetWidth());
		DataFlowException e(SinkName(), msg);
		throw e;
	}

	// Begin Execution
	if(!(output.IsCurrent())){
		output.ResetSize(input1->GetHeight(), input1->GetWidth());
		output.InitData();
		int width = output.GetWidth();
		int height = output.GetHeight();
		Pixel *outData = output.GetData();
		Pixel *input1Data = input1->GetData();
		Pixel *input2Data = input2->GetData();
	
		for(int i = 0; i < width*height; i++){
			outData[i].r = (input1Data[i].r < input2Data[i].r) ? 0 : input1Data[i].r - input2Data[i].r;
			outData[i].g = (input1Data[i].g < input2Data[i].g) ? 0 : input1Data[i].g - input2Data[i].g;
			outData[i].b = (input1Data[i].b < input2Data[i].b) ? 0 : input1Data[i].b - input2Data[i].b;
		}
		output.SetCurrent(true);
	}
}
void Subtract::Update(){
	Filter::Update();
}
const char *Subtract::FilterName(){
	return "Subtract";
}


// Grayscale
Grayscale::Grayscale(void){
	output.SetSource(this);
}
Grayscale::~Grayscale(void){;}
void Grayscale::Execute(){
	char msg[128];

	// Error checks
	if(input1 == NULL){
		sprintf(msg, "%s: no input1!", SinkName());
		DataFlowException e(SinkName(), msg);
		throw e;
	}

	// Begin execution
	if(!(output.IsCurrent())){
		output.ResetSize(input1->GetHeight(), input1->GetWidth());
		output.InitData();
		int height = output.GetHeight();
		int width = output.GetWidth();
		Pixel *outData = output.GetData();
		Pixel *inData = input1->GetData();
		
		for(int i = 0; i < height*width; i++){
			int val = inData[i].r/5 + inData[i].g/2 + inData[i].b/4;
			outData[i].r = (unsigned char) val;
			outData[i].g = (unsigned char) val;
			outData[i].b = (unsigned char) val;
		}
		output.SetCurrent(true);
	}
}
void Grayscale::Update(){
	Filter::Update();
}
const char *Grayscale::FilterName(){
	return "Grayscale";
}


// Blur
Blur::Blur(void){
	output.SetSource(this);
}
Blur::~Blur(void){;}
void Blur::Execute(){
	char msg[128];

	// Error checks
	if(input1 == NULL){
		sprintf(msg, "%s: no input1!", SinkName());
		DataFlowException e(SinkName(), msg);
		throw e;
	}

	// Begin execution
	if(!(output.IsCurrent())){
		output.ResetSize(input1->GetHeight(), input1->GetWidth());
		output.InitData();
		int height = output.GetHeight();
		int width = output.GetWidth();
		Pixel *outData = output.GetData();
		Pixel *inData = input1->GetData();
		
		for(int i = 0; i < height; i++){
			for(int j = 0; j < width; j++){
				if(i==0 || i==(height-1) || j==0 || j==(width-1)){
					outData[i*width+j] = inData[i*width+j];
				}else{
					outData[i*width+j].r =  inData[(i-1)*width+j-1].r/8 + 
								inData[(i-1)*width+j].r/8 + 
								inData[(i-1)*width+j+1].r/8 + 
						   		inData[i*width+j-1].r/8 + 
								inData[i*width+j+1].r/8 +
						   		inData[(i+1)*width+j-1].r/8 + 
								inData[(i+1)*width+j].r/8 + 
								inData[(i+1)*width+j+1].r/8;
					outData[i*width+j].g =  inData[(i-1)*width+j-1].g/8 + 
								inData[(i-1)*width+j].g/8 + 
								inData[(i-1)*width+j+1].g/8 + 
						   		inData[i*width+j-1].g/8 + 
								inData[i*width+j+1].g/8 +
						   		inData[(i+1)*width+j-1].g/8 + 
								inData[(i+1)*width+j].g/8 + 
								inData[(i+1)*width+j+1].g/8;
					outData[i*width+j].b =  inData[(i-1)*width+j-1].b/8 + 
								inData[(i-1)*width+j].b/8 + 
								inData[(i-1)*width+j+1].b/8 + 
						   		inData[i*width+j-1].b/8 + 
								inData[i*width+j+1].b/8 +
						   		inData[(i+1)*width+j-1].b/8 + 
								inData[(i+1)*width+j].b/8 + 
								inData[(i+1)*width+j+1].b/8;
				}
			}
		}
		output.SetCurrent(true);
	}
}
void Blur::Update(){
	Filter::Update();
}
const char *Blur::FilterName(){
	return "Blur";
}


// Color
Color::Color(void){
	output.SetSource(this);
}
Color::Color(int w, int h, unsigned char r, unsigned char g, unsigned char b){
	width = w;
	height = h;
	red = r;
	green = g;
	blue = b;
	output.SetSource(this);
}
Color::~Color(void){;}
void Color::Execute(){
	char msg[128];

	// Error checks
	if(height < 1){
		sprintf(msg, "%s: invalid height: %d", SourceName(), height);
		DataFlowException e(SourceName(), msg);
		throw e;
	}
	if(width < 1){
		sprintf(msg, "%s: invalid width: %d", SourceName(), width);
		DataFlowException e(SourceName(), msg);
		throw e;
	}
	// r, g, b values guaranteed to be 0 < n < 255 due to typing. Error checking should take place when object is created, if desired.

	// Begin execution
	if(!(output.IsCurrent())){
		output.ResetSize(height, width);
		output.InitData();
		Pixel *outData = output.GetData();
		for(int i = 0; i < height*width; i++){
			outData[i].r = red;
			outData[i].g = green;
			outData[i].b = blue;
		}
		output.SetCurrent(true);
	}
}
void Color::Update(){
	char msg[128];
	
	sprintf(msg, "%s: about to execute", SourceName());
	Logger::LogEvent(msg);
	this->Execute();
	sprintf(msg, "%s: done executing", SourceName());
	Logger::LogEvent(msg);
}
const char *Color::SourceName(){
	return "Color";
}


// CheckSum
CheckSum::CheckSum(void){;}
CheckSum::~CheckSum(void){;}
void CheckSum::OutputCheckSum(const char *filename){
	unsigned char red = 0;
	unsigned char green = 0;
	unsigned char blue = 0;
	int height = input1->GetHeight();
	int width = input1->GetWidth();
	Pixel *data = input1->GetData();
	for(int i  = 0; i < height*width; i++){
		red += data[i].r;
		green += data[i].g;
		blue += data[i].b;
	}

	ofstream cs_out;
	
	cs_out.open(filename);

	cs_out << "CHECKSUM: " << (int) red << ", " << (int) green << ", " << (int) blue << endl;
	cs_out.close();
}
const char *CheckSum::SinkName(){
	return "CheckSum";
}
