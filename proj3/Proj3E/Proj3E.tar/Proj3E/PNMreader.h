#ifndef PNMREADER_H
#define PNMREADER_H

#include "image.h"
#include "source.h"

class PNMreader : public Source{
	
	char * filename;	

	protected:
	virtual void Execute();

	public:
	PNMreader(char * str);
	virtual ~PNMreader(void);	
	virtual void Update();
};

#endif
