#ifndef SOURCE_H
#define SOURCE_H

#include "image.h"

class Source{
	protected:
	Image output;
	virtual void Execute() = 0;

	public:
	Source(void);
	virtual ~Source(void);
	virtual void Update() = 0;
	virtual Image * GetOutput();
};

#endif
