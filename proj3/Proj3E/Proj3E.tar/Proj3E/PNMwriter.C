#include "PNMwriter.h"
#include "image.h"
#include <iostream>
#include <fstream>

using namespace std;

PNMwriter::PNMwriter(void){
	;
}
PNMwriter::~PNMwriter(void){
	;
}	

void PNMwriter::Write(char *outfile){
	ofstream f_out;
	
	f_out.open(outfile);

	f_out << "P6\n" << input1->GetWidth() << " " << input1->GetHeight() << "\n" << input1->GetMaxval() << endl;
	Pixel *data = input1->GetData();
	f_out.write( (char *) data, input1->GetHeight()*input1->GetWidth()*sizeof(Pixel));
	f_out.close();
}
