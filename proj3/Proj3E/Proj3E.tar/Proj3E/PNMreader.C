#include "PNMreader.h"
#include "image.h"
#include <string.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>

using namespace std;

PNMreader::PNMreader(char * infile){
	output.SetSource(this);
	filename = strdup(infile);
}
PNMreader::~PNMreader(void){
	free(filename);
}

void PNMreader::Execute(){
	ifstream f;
	f.open(filename);

	string magicNum;
	int width, height, maxval;

	f >> magicNum >> width >> height >> maxval;

	output.ResetSize(height, width);
	output.SetMaxval(maxval);
	output.InitData();	
	
	// I have no idea why this is necessary, but without it my read is off by one byte.
	f.seekg(1, ios::cur);
	
	Pixel *data = output.GetData();
	f.read( (char *) data, height*width*sizeof(Pixel));
	f.close();
	output.SetCurrent(true);
}
void PNMreader::Update(){
	this->Execute();
}

