#ifndef FILTERS_H
#define FILTERS_H

#include "source.h"
#include "sink.h"
#include "image.h"

class Filter : public Source, public Sink{
	protected:
	virtual void Execute() = 0;

	public:
	Filter(void);
	virtual ~Filter(void);
	virtual void Update() = 0;
};

class Shrinker : public Filter{
	protected:
	virtual void Execute();

	public:
	Shrinker(void);
	virtual ~Shrinker(void);
	virtual void Update();
};

class LRConcat : public Filter{
	protected:
	virtual void Execute();

	public:
	LRConcat(void);
	virtual ~LRConcat(void);
	virtual void Update();
};

class TBConcat : public Filter{
	protected:
	virtual void Execute();

	public:
	TBConcat(void);
	virtual ~TBConcat(void);
	virtual void Update();
};

class Blender : public Filter{
	protected:
	virtual void Execute();

	private:
	float factor;

	public:
	Blender(void);
	virtual ~Blender(void);
	virtual void Update();

	void SetFactor(float f);
};

#endif
