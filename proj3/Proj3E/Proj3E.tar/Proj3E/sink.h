#ifndef SINK_H
#define SINK_H

#include "image.h"

class Sink {
	protected:
	Image *input1, *input2;

	public:
	Sink(void);
	virtual ~Sink(void);

	virtual void SetInput(Image *);
	virtual void SetInput2(Image *);
};

#endif
