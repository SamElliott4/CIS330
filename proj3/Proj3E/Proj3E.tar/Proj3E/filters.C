#include "filters.h"
#include <string.h>
#include <iostream>

using std::cout;
using std::endl;

// Filter
Filter::Filter(void){;}
Filter::~Filter(void){;}


// Shrinker
Shrinker::Shrinker(void){
	output.SetSource(this);
}
Shrinker::~Shrinker(void){;}

void Shrinker::Execute(){
	output.ResetSize((this->input1->GetHeight()+1)/2, (this->input1->GetWidth()+1)/2);
	output.InitData();
	Pixel * outData = output.GetData();
	Pixel * inData = this->input1->GetData();
	int outHeight = output.GetHeight();
	int outWidth = output.GetWidth();
	int inWidth = this->input1->GetWidth();
	for(int i = 0; i < outHeight; i++){
		for(int j = 0; j<outWidth; j++){
			outData[i*outWidth+j] = inData[i*2*inWidth+j*2];
		}
	}
	output.SetCurrent(true); 
}

void Shrinker::Update(){
	if(!input1->IsCurrent()){
		input1->Update();
	}
	this->Execute();
}


// LRConcat
LRConcat::LRConcat(void){
	output.SetSource(this);
}
LRConcat::~LRConcat(void){;}

void LRConcat::Execute(){
	output.ResetSize(input1->GetHeight(), input1->GetWidth() + input2->GetWidth());
	output.InitData();
	int outHeight = output.GetHeight();
	int outWidth = output.GetWidth();
	int leftWidth = input1->GetWidth();
	int rightWidth = input2->GetWidth();
	Pixel *outData = output.GetData();
	Pixel *leftData = input1->GetData();
	Pixel *rightData = input2->GetData();

	for(int i = 0; i < outHeight; i++){
		memcpy(outData + i*outWidth, leftData + i*leftWidth, leftWidth*sizeof(Pixel));
		memcpy(outData + i*outWidth + leftWidth, rightData + i*rightWidth, rightWidth*sizeof(Pixel));
	}
	output.SetCurrent(true); 
}

void LRConcat::Update(){
	if(!input1->IsCurrent()){
		input1->Update();
	}
	if(!input2->IsCurrent()){
		input2->Update();
	}
	this->Execute();
}


// TBConcat
TBConcat::TBConcat(void){
	output.SetSource(this);
}
TBConcat::~TBConcat(void){;}

void TBConcat::Execute(){
	output.ResetSize(input1->GetHeight() + input2->GetHeight(), input1->GetWidth());
	output.InitData();
	Pixel * outData = output.GetData();
	memcpy(outData, input1->GetData(), input1->GetHeight()*input1->GetWidth()*sizeof(Pixel));
	memcpy(outData + input1->GetHeight()*input1->GetWidth(), input2->GetData(), input2->GetHeight()*input2->GetWidth()*sizeof(Pixel));
	output.SetCurrent(true); 
}

void TBConcat::Update(){
	if(!input1->IsCurrent()){
		input1->Update();
	}
	if(!input2->IsCurrent()){
		input2->Update();
	}
	this->Execute();
}


// Blender
Blender::Blender(void){
	output.SetSource(this);
}
Blender::~Blender(void){;}

void Blender::Execute(){
	output.ResetSize(input1->GetHeight(), input2->GetWidth());
	output.InitData();
	Pixel *outData = output.GetData();
	Pixel *input1Data = input1->GetData();
	Pixel *input2Data = input2->GetData();
	int outHeight = output.GetHeight();
	int outWidth = output.GetWidth();
	for(int i = 0; i < outHeight*outWidth; i++){
		outData[i].r = input1Data[i].r * factor + input2Data[i].r * (1-factor);
		outData[i].g = input1Data[i].g * factor + input2Data[i].g * (1-factor);
		outData[i].b = input1Data[i].b * factor + input2Data[i].b * (1-factor);
	}
	output.SetCurrent(true); 
}
void Blender::SetFactor(float f){
	factor = f;
}

void Blender::Update(){
	if(!input1->IsCurrent()){
		input1->Update();
	}
	if(!input2->IsCurrent()){
		input2->Update();
	}
	this->Execute();
}
