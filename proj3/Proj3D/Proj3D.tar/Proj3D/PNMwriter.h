#ifndef PNMWRITER_H
#define PNMWRITER_H

#include "image.h"
#include "sink.h"

class PNMwriter : public Sink{

	public:
	PNMwriter(void);
	virtual ~PNMwriter(void);

	virtual void Write(char * outfile);

};

#endif
