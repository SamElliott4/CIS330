#include <source.h>
#include <image.h>

// Source
Source::Source(void){
	;
}
Source::~Source(void){
	;
}

Image * Source::GetOutput(){
	return &output;
}

